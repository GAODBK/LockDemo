package com.ztk.demo.lockdemo;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import com.ztk.demo.lockdemo.notification.NotificationUtil;
import com.ztk.demo.lockdemo.service.PlayService;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            fullScreen(this);
        }

        //开启播放服务
        Intent intent = new Intent(this, PlayService.class);
        startService(intent);

        //开启通知栏
        NotificationUtil mNotificationUtils = new NotificationUtil(this);
        mNotificationUtils.showNotification();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void fullScreen(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            //5.x开始需要把颜色设置透明，否则导航栏会呈现系统默认的浅灰色
            Window window = activity.getWindow();
            View decorView = window.getDecorView();

            //两个 flag 要结合使用，表示让应用的主体内容占用系统状态栏的空间
            int option = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN //系统 UI 标志布局全屏
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE // 系统 UI 标志布局稳定
                    | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; // 将系统栏图标设为黑色;
            decorView.setSystemUiVisibility(option);

            window.addFlags(
                    WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
        }
    }
}

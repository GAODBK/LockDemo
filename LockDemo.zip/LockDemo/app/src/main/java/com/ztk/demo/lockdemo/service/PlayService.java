package com.ztk.demo.lockdemo.service;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import com.ztk.demo.lockdemo.LockActivity;
import androidx.annotation.Nullable;
public class PlayService extends Service {
    // 调用的 第 3 个类
    ScreenBroadcastReceiver screenBroadcastReceiver;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        // 注册广播
        screenBroadcastReceiver = new ScreenBroadcastReceiver();
        final IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screenBroadcastReceiver, filter);
    }

    public class ScreenBroadcastReceiver extends BroadcastReceiver {
        // 调用的 第 3.1 个类
        @Override
        public void onReceive(Context context, Intent intent) {

            handleCommandIntent(intent);
        }
    }

    private void handleCommandIntent(Intent intent) {
        final String action = intent.getAction();

            Intent lockScreen = new Intent(this, LockActivity.class);
            lockScreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        if (Intent.ACTION_SCREEN_OFF.equals(action)) {// 当操作屏幕关闭时
            startActivity(lockScreen);
        } else if (Intent.ACTION_SCREEN_ON.equals(action)) {// 当操作屏幕打开时
            startActivity(lockScreen);
        } else if (Intent.ACTION_USER_PRESENT.equals(action)) {// 当操作屏幕解锁时

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(screenBroadcastReceiver);
    }
}
